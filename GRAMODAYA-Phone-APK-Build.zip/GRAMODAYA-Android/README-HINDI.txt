GRAMODAYA Android Test Project

यह Android Studio project है; तैयार APK नहीं है। इस environment में Android SDK/Gradle उपलब्ध नहीं थे, इसलिए यहाँ APK compile नहीं किया जा सका।

APK बनाने के लिए:
1. कंप्यूटर में Android Studio install करें।
2. इस ZIP को extract करें।
3. Android Studio में GRAMODAYA-Android folder खोलें।
4. Gradle sync पूरा होने दें (internet चाहिए)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।

ऐप का UI assets/index.html में है। फाइनल Green-White UI और पाँच bottom navigation tabs यथावत रखे गए हैं। यह demo है: sample courses/classes हैं; असली online video hosting, login/backend और वास्तविक download functionality अभी जुड़ी नहीं है।
